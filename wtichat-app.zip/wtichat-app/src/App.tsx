import { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Sun, Moon, Mic } from "lucide-react";
import { motion } from "framer-motion";

export default function WTIchat() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "कैसे मदद करूं? WTIchat में आपका स्वागत करना है!" }
  ]);
  const [input, setInput] = useState("");
  const [darkMode, setDarkMode] = useState(true);
  const [language, setLanguage] = useState("hindi");
  const [isTyping, setIsTyping] = useState(false);
  const chatRef = useRef(null);
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'hi-IN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onresult = (event) => {
        const speechToText = event.results[0][0].transcript;
        setInput(speechToText);
      };

      recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
      };

      recognitionRef.current = recognition;
    } else {
      console.warn("SpeechRecognition not supported in this browser.");
    }
  }, []);

  const languageResponses = {
    hindi: "जी हां! मैं WTIchat हूं, और मैं कोशिश जवाब दे और जाएगा!",
    english: "Hey there! I'm WTIchat, your intelligent Indian AI assistant.",
    hinglish: "Namaste! Main hoon WTIchat – smart AI jo Hindi, Hinglish aur English samajhta hai!"
  };

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMessage = { sender: "user", text: input };
    setMessages((prev) => [...prev, userMessage]);
    setIsTyping(true);
    setTimeout(() => {
      const botReply = { sender: "bot", text: languageResponses[language] };
      setMessages((prev) => [...prev, botReply]);
      setIsTyping(false);
    }, 1000);
    setInput("");
  };

  const startVoice = () => {
    if (recognitionRef.current && recognitionRef.current.state !== 'recording') {
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.error("Speech recognition already started or not supported.");
      }
    } else {
      alert("Speech Recognition is already in progress or not supported.");
    }
  };

  const bgClass = darkMode
    ? "bg-gradient-to-br from-black via-zinc-900 to-gray-800 text-white"
    : "bg-gradient-to-br from-[#f0f9ff] via-white to-[#e0ecff] text-gray-900";
  const inputClass = darkMode ? "bg-zinc-800 text-white" : "bg-white text-black border border-zinc-300";

  return (
    <div className={`relative min-h-screen ${bgClass} p-6 md:p-10 flex flex-col items-center transition-all duration-300 font-sans overflow-hidden`}>
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <canvas id="particles-canvas" className="w-full h-full"></canvas>
      </div>

      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex justify-between w-full max-w-5xl mb-6 items-center"
      >
        <h1 className="text-xl md:text-2xl font-extrabold bg-gradient-to-r from-pink-500 via-violet-500 to-indigo-600 text-transparent bg-clip-text drop-shadow-2xl">
          WTIchat
        </h1>
        <div className="flex items-center gap-3">
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="rounded-lg px-3 py-2 text-sm bg-white text-black border border-gray-300 shadow-sm"
          >
            <option value="hindi">Hindi</option>
            <option value="english">English</option>
            <option value="hinglish">Hinglish</option>
          </select>
          <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? <Sun className="text-yellow-400" /> : <Moon className="text-zinc-900" />}
          </Button>
        </div>
      </motion.div>

      <motion.div
        ref={chatRef}
        className="w-full max-w-5xl h-[540px] overflow-y-auto p-6 rounded-3xl backdrop-blur-2xl bg-white/10 border border-white/20 shadow-2xl space-y-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
      >
        {messages.map((msg, idx) => (
          <motion.div
            key={idx}
            className={`max-w-[80%] px-6 py-4 rounded-3xl text-base md:text-lg tracking-wide leading-relaxed break-words transition-all duration-300 ${
              msg.sender === "user"
                ? "bg-gradient-to-br from-blue-500 to-indigo-600 text-white self-end ml-auto shadow-xl"
                : darkMode
                ? "bg-white/10 text-white shadow-md"
                : "bg-white text-gray-800 shadow-md"
            }`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
          >
            {msg.text}
          </motion.div>
        ))}

        {isTyping && (
          <div className="animate-pulse text-sm text-gray-400 ml-4">WTIchat is typing...</div>
        )}
      </motion.div>

      <motion.div
        className="flex w-full max-w-5xl mt-6 gap-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Input
          placeholder="Type your message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          className={`${inputClass} px-5 py-4 rounded-3xl text-base shadow-inner focus:ring-2 focus:ring-violet-500 focus:outline-none`}
        />
        <Button
          onClick={sendMessage}
          className="rounded-3xl px-6 py-4 bg-gradient-to-br from-fuchsia-600 to-purple-700 hover:brightness-110 text-white font-bold text-base shadow-xl"
        >
          Send
        </Button>
        <Button
          onClick={startVoice}
          variant="outline"
          className="rounded-full p-4 border-2 border-violet-400 text-violet-600 hover:bg-violet-100"
        >
          <Mic className="w-5 h-5" />
        </Button>
      </motion.div>

      <footer className="mt-10 text-sm text-center text-gray-400">
        <p>© {new Date().getFullYear()} WTIchat. Powered by <a href="https://www.webtechinfinity.com" className="underline">WebTech Infinity</a></p>
        <div className="mt-2 flex justify-center gap-4">
          <a href="/privacy" className="underline">Privacy Policy</a>
          <a href="/terms" className="underline">Terms of Use</a>
          <a href="/contact" className="underline">Contact Us</a>
        </div>
      </footer>
    </div>
  );
}
